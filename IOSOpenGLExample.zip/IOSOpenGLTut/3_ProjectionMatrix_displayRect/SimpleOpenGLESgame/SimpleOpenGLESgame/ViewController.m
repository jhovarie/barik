//
//  ViewController.m
//  SimpleOpenGLESgame
//
//  Created by Jhovarie on 13/07/2016.
//  Copyright © 2016 Jhovarie. All rights reserved.
//


/*
 Need to add Library
 1) QuartzCore.framework
 2) CoreGraphics.framework
 3) GLKit.framework
 4) OpenGLES.framework
 
 In story board click your ViewController select View then in the class select "GLKView"
 */


#import "ViewController.h"

typedef struct {
    GLKVector3 positionCoordinates;
} VertextData;

#define SQUARE_SIZE 80.0f;
//float SQUARE_SIZE = 80.0f;

/*
VertextData vertices[] = {
    {-0.5f, -0.5f, 0.0f},
    {0.5f, -0.5f, 0.0f},
    {-0.5f, 0.5f, 0.0f},
    {-0.5f, 0.5f, 0.0f},
    {0.5f, -0.5f, 0.0f},
    {0.5f, 0.5f, 0.0f}
};
*/

VertextData vertices[] = {
    {0.0f, 0.0f, 0.0f},
    {80.0f, 0.0f, 0.0f},
    {0.0f, 80.0f, 0.0f},
    {0.0f, 80.0f, 0.0f},
    {80.0f, 0.0f, 0.0f},
    {80.0f, 80.0f, 0.0f}
};

@interface ViewController () {
    GLuint _vertexBufferID;
}

@property (nonatomic, strong) EAGLContext *context;
@property (nonatomic, strong) GLKBaseEffect *baseEffect;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.context = [[EAGLContext alloc]initWithAPI:kEAGLRenderingAPIOpenGLES2];
    GLKView *view = (GLKView *)self.view;
    view.context = self.context;
    [EAGLContext setCurrentContext:self.context];
    
    self.baseEffect = [[GLKBaseEffect alloc]init];
    self.baseEffect.useConstantColor = YES;
    self.baseEffect.constantColor = GLKVector4Make(1.0f, 0.0f, 0.0f, 1.0f);
    
    int screenwidth = [UIScreen mainScreen].applicationFrame.size.width * 2;
    int screenheight = [UIScreen mainScreen].applicationFrame.size.height * 2;
    //NSLog(@"w %i h %i", screenwidth,screenheight );
    self.baseEffect.transform.projectionMatrix = GLKMatrix4MakeOrtho(0, screenwidth, 0,  screenheight, -1, 1);
   //self.baseEffect.transform.projectionMatrix = GLKMatrix4MakeOrtho(0, 640, 0, 1136, -1, 1);
    //self.baseEffect.transform.projectionMatrix = GLKMatrix4MakeOrtho(0, 1080, 0, 1920, -1, 1);
    
     //  self.baseEffect.transform.projectionMatrix = GLKMatrix4O
    
    //r g b a
    glClearColor(1.0f, 1.0f, 1.0f, 1.0f);

    
    glGenBuffers(1, &_vertexBufferID);
    glBindBuffer(GL_ARRAY_BUFFER, _vertexBufferID);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);
    glEnableVertexAttribArray(GLKVertexAttribPosition);
    glVertexAttribPointer(GLKVertexAttribPosition, 3, GL_FLOAT, GL_FALSE, sizeof(VertextData), NULL);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark glkView delegates methods

-(void) glkView:(GLKView *)view drawInRect:(CGRect)rect {
    glClear(GL_COLOR_BUFFER_BIT);
    
    [self.baseEffect prepareToDraw];
    glDrawArrays(GL_TRIANGLES, 0, 6);
}

-(void) update {
    
}

@end
