//
//  Sprite.h
//  SimpleOpenGLESgame
//
//  Created by Jhovarie on 13/07/2016.
//  Copyright © 2016 Jhovarie. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <GLKit/GLkit.h>

#define SQUARE_SIZE 80.0f


@interface Sprite : NSObject

-(id)initWithEffect: (GLKBaseEffect *)baseEffect;

@property (nonatomic, strong) GLKTextureInfo *textureInfo;
@property (assign) GLKVector2 position;
@property (assign) float rotation;
@property (assign) float rotateionVelocity;
@property (assign) GLKVector2 velocity;

-(void)render;
-(void)update;

@end
