//
//  ViewController.m
//  SimpleOpenGLESgame
//
//  Created by Jhovarie on 13/07/2016.
//  Copyright © 2016 Jhovarie. All rights reserved.
//


/*
 Need to add Library
 1) QuartzCore.framework
 2) CoreGraphics.framework
 3) GLKit.framework
 4) OpenGLES.framework
 
 In story board click your ViewController select View then in the class select "GLKView"
 */


#import "ViewController.h"

/*
typedef struct {
    GLKVector3 positionCoordinates;
} VertextData;
*/

/*
VertextData vertices[] = {
    {-0.5f, -0.5f, 0.0f},
    {0.5f, -0.5f, 0.0f},
    {-0.5f, 0.5f, 0.0f},
    {-0.5f, 0.5f, 0.0f},
    {0.5f, -0.5f, 0.0f},
    {0.5f, 0.5f, 0.0f}
};
*/

typedef struct {
    GLKVector3 positionCoordinates;
    GLKVector2 textureCoordinates;
}  VertextData;

/*
VertextData vertices[] =
{
    {{-1.0f, -0.67f, 0.0f}, {0.0f, 0.0f}},  // first triangle
    {{ 1.0f, -0.67f, 0.0f}, {1.0f, 0.0f}},
    {{-1.0f,  0.67f, 0.0f}, {0.0f, 1.0f}},
    {{ 1.0f, -0.67f, 0.0f}, {1.0f, 0.0f}},  // second triangle
    {{-1.0f,  0.67f, 0.0f}, {0.0f, 1.0f}},
    {{ 1.0f,  0.67f, 0.0f}, {1.0f, 1.0f}},
};
*/

VertextData vertices[] = {
    {{-0.5f, -0.5f, 0.0f}, {0.0f, 0.0f}},
    {{0.5f, -0.5f, 0.0f}, {1.0f, 0.0f}},
    {{-0.5f, 0.5f, 0.0f}, {0.0f, 1.0f}},
    {{0.5f, -0.5f, 0.0f}, {1.0f, 0.0f}},
    {{-0.5f, 0.5f, 0.0f}, {0.0f, 1.0f}},
    {{0.5f, 0.5f, 0.0f}, {1.0f, 1.0f}},
};


@interface ViewController () {
    GLuint _vertexBufferID;
    GLKTextureInfo *textureInfo;
    bool orthoview;
}

@property (nonatomic, strong) EAGLContext *context;
@property (nonatomic, strong) GLKBaseEffect *baseEffect;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    orthoview = false;
    
    self.context = [[EAGLContext alloc]initWithAPI:kEAGLRenderingAPIOpenGLES2];
    GLKView *view = (GLKView *)self.view;
    view.context = self.context;
    [EAGLContext setCurrentContext:self.context];
    
    self.baseEffect = [[GLKBaseEffect alloc]init];
    self.baseEffect.useConstantColor = YES;
   // self.baseEffect.constantColor = GLKVector4Make(1.0f, 0.0f, 0.0f, 1.0f);
    
    //r g b a
    glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
    
    glGenBuffers(1, &_vertexBufferID);
    glBindBuffer(GL_ARRAY_BUFFER, _vertexBufferID);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);
    glEnableVertexAttribArray(GLKVertexAttribPosition);
   // glVertexAttribPointer(GLKVertexAttribPosition, 3, GL_FLOAT, GL_FALSE, sizeof(VertextData), NULL);
    
    glVertexAttribPointer(GLKVertexAttribPosition, 3, GL_FLOAT, GL_FALSE, sizeof(VertextData), offsetof(VertextData, positionCoordinates));
    
    
    glEnableVertexAttribArray(GLKVertexAttribTexCoord0);
    
    glVertexAttribPointer(GLKVertexAttribTexCoord0, 2, GL_FLOAT, GL_FALSE,sizeof(VertextData), (GLvoid *) offsetof(VertextData, textureCoordinates));
    
    
    //texture ---------------------------------------------
    NSDictionary * nsdictionaryoptions = [NSDictionary dictionaryWithObjectsAndKeys:
                                          [NSNumber numberWithBool:YES],
                                          GLKTextureLoaderOriginBottomLeft,
                                          nil];
    CGImageRef imageReference = [[UIImage imageNamed:@"smile.png"] CGImage];
    GLKTextureInfo *textureInfo2 = [GLKTextureLoader textureWithCGImage:imageReference options:nsdictionaryoptions error:NULL];
    
    textureInfo = textureInfo2;
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark glkView delegates methods

-(void) glkView:(GLKView *)view drawInRect:(CGRect)rect {
    glClear(GL_COLOR_BUFFER_BIT);
    
    [self.baseEffect prepareToDraw];
    self.baseEffect.texture2d0.name = textureInfo.name;
    self.baseEffect.texture2d0.target = textureInfo.target;
    [self.baseEffect prepareToDraw];
    //glDrawArrays(GL_TRIANGLES, 0, sizeof(vertices));
    glDrawArrays(GL_TRIANGLES, 0, 6);

}

-(void) update {
    
}

@end
