package com.example.opengl;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.ShortBuffer;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

import android.app.Activity;
import android.opengl.GLSurfaceView;
import android.opengl.GLU;
import android.opengl.GLSurfaceView.Renderer;
import android.os.Bundle;
import android.os.SystemClock;

public class GLCube3D extends Activity {
	GLSurfaceView ourSurface;
	Activity act;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		ourSurface = new GLSurfaceView(this);
		ourSurface.setEGLConfigChooser(8 , 8, 8, 8, 16, 0);
		ourSurface.setRenderer(new GLCubeRendererEx());
		setContentView(ourSurface);
		act = this;
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		ourSurface.onPause();
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		ourSurface.onResume();
	}
	
	class GLCubeRendererEx implements Renderer {
		private GLCube cube;
		
		public GLCubeRendererEx() {
			cube = new GLCube(act);
		}
		
		@Override
		public void onSurfaceCreated(GL10 gl, EGLConfig eglConfig) {
			// TODO Auto-generated method stub
			gl.glDisable(GL10.GL_DITHER);
			gl.glHint(GL10.GL_PERSPECTIVE_CORRECTION_HINT, GL10.GL_FASTEST);
			gl.glClearColor(.8f, 0f, .2f, 1f);
			gl.glClearDepthf(1f);
			
		}
		
		@Override
		public void onDrawFrame(GL10 gl) {
			gl.glDisable(GL10.GL_DITHER);
			gl.glClear(GL10.GL_COLOR_BUFFER_BIT | GL10.GL_DEPTH_BUFFER_BIT);
			gl.glMatrixMode(GL10.GL_MODELVIEW);
			gl.glLoadIdentity();
			GLU.gluLookAt(gl, 0, 0, -5, 0, 0, 0, 0, 2, 0);
			
			long time = SystemClock.uptimeMillis() % 4000L;
			float angle = .090f * ((int)time);
			gl.glRotatef(angle, 1, 0, 2);
			//gl.glRotatef(angle, 1, 0, 0);
			//gl.glRotatef(angle, 0, 0, 1);
			cube.draw(gl);
		}

		@Override
		public void onSurfaceChanged(GL10 gl, int width, int height) {
			// TODO Auto-generated method stub
			gl.glViewport(0, 0, width, height);
			float ratio = (float) width/ height;
			gl.glMatrixMode(GL10.GL_PROJECTION);
			gl.glLoadIdentity();
			gl.glFrustumf(-ratio, ratio, -1, 1, 1, 25);
		}
	}

	class GLCube {
		Activity act;
		private float vertices[] = {
			1, 1, -1, // p0 -topFront Right
			1, -1, -1, // p1 bottomFront Right
			-1, -1, -1, // p2 bottomFront Left
			-1, 1, -1, // p3 front top Left
			
			1, 1,  1, // p4 -topBack Right
			1, -1, 1, // p5 bottom Back Right
			-1, -1, 1, // p6 bottom Back Left
			-1, 1,  1, // p7 front top Left
		};
		
		private FloatBuffer vertBuff;
		private short[] pIndex = {
				3, 4, 0, 	0, 4, 1,	3, 0, 1,
				3, 7, 4,	7, 6, 4,	7, 3, 6,
				3, 1, 2,	1, 6, 2,	6, 3, 2,
				1, 4, 5,	5, 6, 1,	6, 5, 4
		};
		private ShortBuffer pBuff;
		
		public GLCube(Activity act) {
			this.act = act;
			
			ByteBuffer bBuff = ByteBuffer.allocateDirect(vertices.length * 4);
			bBuff.order(ByteOrder.nativeOrder());
			vertBuff = bBuff.asFloatBuffer();
			vertBuff.put(vertices);
			vertBuff.position(0);
			
			ByteBuffer pbBuff = ByteBuffer.allocateDirect(pIndex.length * 2);
			pbBuff.order(ByteOrder.nativeOrder());
			pBuff = pbBuff.asShortBuffer();
			pBuff.put(pIndex);
			pBuff.position(0);
		}
		
		public void draw(GL10 gl) {
			gl.glFrontFace(GL10.GL_CW);
			gl.glEnable(GL10.GL_CULL_FACE);
			gl.glCullFace(GL10.GL_BACK);
			gl.glEnableClientState(GL10.GL_VERTEX_ARRAY);
			gl.glVertexPointer(3, GL10.GL_FLOAT, 0, vertBuff); //glVertexPointer 2 for 2d and 3 for 3d
			gl.glDrawElements(GL10.GL_TRIANGLES, pIndex.length, GL10.GL_UNSIGNED_SHORT, pBuff);
			gl.glDisableClientState(GL10.GL_VERTEX_ARRAY);
			gl.glDisable(GL10.GL_CULL_FACE);
		}
	}
}
