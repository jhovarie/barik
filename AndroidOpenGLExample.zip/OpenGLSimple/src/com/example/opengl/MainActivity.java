package com.example.opengl;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}
	
	public void goTriangle(View v){
		startActivity(new Intent(this,GL2DTriangle .class));
	}
	
	public void goTriangle2(View v){
		//GL2DTriangleImageExample
		startActivity(new Intent(this, GL2DTriangleColord.class));
	}
	
	public void goCube(View v){
		startActivity(new Intent(this, GLCube3D.class));
	}
	
	public void goSquare(View v) {
		startActivity(new Intent(this, GL2DSquare.class));
	}
	
	public void goSquareTexture(View v){
		startActivity(new Intent(this, GL2DSquareTexture.class));
	}
	
	public void goTriangle3(View v){
		//startActivity(new Intent(this, GL2DTriangleImage.class));
	}
}
