//
//  ViewController.m
//  SimpleOpenGLESgame
//
//  Created by Jhovarie on 13/07/2016.
//  Copyright © 2016 Jhovarie. All rights reserved.
//


/*
 Need to add Library
 1) QuartzCore.framework
 2) CoreGraphics.framework
 3) GLKit.framework
 4) OpenGLES.framework
 
 In story board click your ViewController select View then in the class select "GLKView"
 */


#import "ViewController.h"
#import "OpenGLView.h"

@interface ViewController () {
    OpenGLView* _glView;
}

@property (nonatomic, strong) EAGLContext *context;
@property (nonatomic, strong) GLKBaseEffect *baseEffect;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    /*
    self.context = [[EAGLContext alloc]initWithAPI:kEAGLRenderingAPIOpenGLES2];
    GLKView *view = (GLKView *)self.view;
    view.context = self.context;
    [EAGLContext setCurrentContext:self.context];
    
    self.baseEffect = [[GLKBaseEffect alloc]init];
    //r g b a
    glClearColor(0.0f, 1.0f, 0.0f, 1.0f);
    */
    
    CGRect screenBounds = [[UIScreen mainScreen] bounds];
    _glView = [[OpenGLView alloc] initWithFrame:screenBounds];
    [self.view addSubview:_glView];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark glkView delegates methods

-(void) glkView:(GLKView *)view drawInRect:(CGRect)rect {
    // glClear(GL_COLOR_BUFFER_BIT);
}

-(void) update {
    
}

@end
