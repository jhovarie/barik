//
//  ViewController.h
//  SimpleOpenGLESgame
//
//  Created by Jhovarie on 13/07/2016.
//  Copyright © 2016 Jhovarie. All rights reserved.
//

#import <GLKit/GLkit.h>
#import <UIKit/UIKit.h>
#import "OpenGLView.h"

//@interface ViewController : UIViewController

//Change baseclass from ViewController to GLKViewController
@interface ViewController : GLKViewController {
    
}

@end

