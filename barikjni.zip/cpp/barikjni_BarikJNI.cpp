#include <jni.h>
#include <stdio.h>
#include <cstdlib> //suport system
#include <fstream>
#include <iostream>
#include <string>
#include <cstring>
#include <tr1/memory>
#include "barikjni_BarikJNI.h"
//C:\Program Files\Java\jdk1.8.0_31\include\win32
//C:\Program Files\Java\jdk1.8.0_31\include

//convert jstring to cchar
const char *convertJStringToCChar(JNIEnv *env, jstring jstr) {
    const char *str = env->GetStringUTFChars(jstr,0); 
	env->ReleaseStringUTFChars(jstr, str); // To avoid memory Leaks   
	return (str);
}

//conver cchar to jstring
jstring convertCCharToJString(JNIEnv *env, const char *str) {
	char *returnString = (char*)malloc(10);
	strcpy(returnString, str);
	jstring jstr = env->NewStringUTF(returnString);
	return jstr;
}

std::string exec(const char* cmd) {
    std::tr1::shared_ptr<FILE> pipe(_popen(cmd, "r"), _pclose);
    if (!pipe) return "ERROR";
    char buffer[128];
    std::string result = "";
    while (!feof(pipe.get())) {
        if (fgets(buffer, 128, pipe.get()) != NULL)
            result += buffer;
    }
    return result;
}

JNIEXPORT jstring JNICALL Java_barikjni_BarikJNI_exec
  (JNIEnv *env, jobject jobj, jstring jstr) {
  	//printf("jni exec");
  	//const char *str = convertJStringToCChar(env, jstr);
   //const char *str= env->GetStringUTFChars(jstr,0); 
    
	//system(convertJStringToCChar(env, jstr)); 
    //std::string execresult = exec(convertJStringToCChar(env, jstr));
    //const char * c_execresult = exec(convertJStringToCChar(env, jstr)).c_str();
    
	//env->ReleaseStringUTFChars(jstr, str); // To avoid memory Leaks       
    //return (jstr); 
    return (convertCCharToJString(env, exec(convertJStringToCChar(env, jstr)).c_str()));
}

  JNIEXPORT void JNICALL Java_barikjni_BarikJNI_writeFile
  (JNIEnv *env, jobject jobj, jstring jstr_targetfile, jstring jstr_content) {
  	const char *targetfile = convertJStringToCChar(env, jstr_targetfile);
  	//const char *targetfile = env->GetStringUTFChars(jstr_targetfile,0); 
  	const char *content = convertJStringToCChar(env, jstr_content); 
  	//const char *content = env->GetStringUTFChars(jstr_content,0); 
  	FILE * pFile;
    pFile = fopen (targetfile,"w"); //Write
  	//pFile = fopen ("myfile.txt","a"); //Append
  	if (pFile!=NULL) {
    	fputs (content,pFile);
    	fclose (pFile);
  	}
  	//env->ReleaseStringUTFChars(jstr_targetfile, targetfile); // To avoid memory Leaks
  	//env->ReleaseStringUTFChars(jstr_content, content); // To avoid memory Leaks
  }
  
