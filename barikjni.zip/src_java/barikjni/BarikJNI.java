/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package barikjni;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author jhovarie
 */
public class BarikJNI {
    static {
        System.loadLibrary("BarikJNI");
    }
    //private native void printHello();
    private native String exec(String cmd);
    //private native String readFile(String sourcefile);
    private native void writeFile(String content, String targetfile);
    public String readFile(String targetFile) throws FileNotFoundException, IOException {
        BufferedReader bfr = new BufferedReader(new FileReader(new File(targetFile)));
        String s = "", s2 = "";
        while((s=bfr.readLine())!=null){
            s2+=s+"\n";
        }
        return s2;
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
       BarikJNI barikjni = new BarikJNI();
     String result = barikjni.exec("javac");
     System.out.println("----------------------------------");
     System.out.println(result);
       //barikjni.writeFile("kamote/test.txt", "this is using jni \nto write");
       //String content = barikjni.readFile("test.txt");
       //System.out.println(">> "+content +" <<");
        //barikjni.printHello();
    }
}
