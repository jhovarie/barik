//
//  VideoClass.cpp
//  018classeswithvideo
//
//  Created by Jhovarie on 09/08/2016.
//
//

#include "VideoClass.hpp"

void VideoClass::setup() {
    video.loadMovie("TOP_GIRL.mp4");
    video.setVolume(0.3);
}

void VideoClass::update() {
    video.update();
}

void VideoClass::draw() {
    video.draw(100, 100, 800, 400);
    
}

void VideoClass::keyPressed(int key) {
    switch(key) {
        case ' ':
            video.play();
            break;
            
        case OF_KEY_LEFT:
            video.previousFrame();
            break;
            
        case OF_KEY_RIGHT:
            video.nextFrame();
            break;
            
        case 's':
            video.stop();
            break;
    }
}