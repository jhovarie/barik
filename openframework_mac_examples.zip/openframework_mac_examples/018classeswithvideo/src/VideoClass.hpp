//
//  VideoClass.hpp
//  018classeswithvideo
//
//  Created by Jhovarie on 09/08/2016.
//
//

#ifndef VideoClass_hpp
#define VideoClass_hpp

//#include <stdio.h>
#include "ofMain.h"

class VideoClass {
public:
    void setup();
    void update();
    void draw();
    void keyPressed(int key);
    
    ofVideoPlayer video;
};

#endif /* VideoClass_hpp */
