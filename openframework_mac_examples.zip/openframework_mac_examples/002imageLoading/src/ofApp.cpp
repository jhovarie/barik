#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){
    image.load("smile.png");
}

//--------------------------------------------------------------
void ofApp::update(){
    if(goingright) {
        if(x < ofGetWidth() - 100) {
            x+=3;
        } else {
            goingright = false;
        }
    } else {
        if(x > 0) {
            x-=3;
        } else {
            goingright = true;
        }
    }
    if(goingdown) {
        if(y < ofGetHeight() - 100) {
            y+=3;
        } else {
            goingdown = false;
        }
    } else {
        if(y > 0) {
            y-=3;
        } else {
            goingdown = true;
        }
    }
}

//--------------------------------------------------------------
void ofApp::draw(){
    //image.draw(0, 0);
   // image.draw(ofGetWidth(), ofGetHeight()); //get window w h
   //image.draw(ofGetWidth()/2, ofGetHeight()/2);
    
    //our sprit is 600x600
    //this draw the sprite in the midle of our window
    //image.draw(ofGetWidth()/2 -300, ofGetHeight()/2- 300);
    
    //x y w h draw sprite at the center of the window
   //image.draw(ofGetWidth() / 2 -50, ofGetHeight() / 2 - 50, 100, 100);
    
    image.draw(x, y, 100, 100);
    
    image.draw(100, 100, 100, 100);
}
