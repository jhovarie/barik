//
//  ImageClass.cpp
//  016classes
//
//  Created by Jhovarie on 09/08/2016.
//
//

#include "ImageClass.hpp"

void ImageClass::setup() {
    image.loadImage("smile.png");
}

void ImageClass::draw() {
   // image.draw(100, 100, 100, 100);
     image.draw(ofGetMouseX()-50, ofGetMouseY()-50, 100, 100);
}