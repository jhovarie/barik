//
//  ImageClass.hpp
//  016classes
//
//  Created by Jhovarie on 09/08/2016.
//
//

#ifndef ImageClass_hpp
#define ImageClass_hpp

//#include <stdio.h>
#include "ofMain.h"

class ImageClass {
public:
    void setup();
    void draw();
    
    ofImage image;
};

#endif /* ImageClass_hpp */
