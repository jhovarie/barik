#include "myProject.h"

//--------------------------------------------------------------
void myProject::setup(){

}

//--------------------------------------------------------------
void myProject::update(){

}

//--------------------------------------------------------------
void myProject::draw(){

}

//--------------------------------------------------------------
void myProject::keyPressed(int key){

}

//--------------------------------------------------------------
void myProject::keyReleased(int key){

}

//--------------------------------------------------------------
void myProject::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void myProject::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void myProject::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void myProject::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void myProject::mouseEntered(int x, int y){

}

//--------------------------------------------------------------
void myProject::mouseExited(int x, int y){

}

//--------------------------------------------------------------
void myProject::windowResized(int w, int h){

}

//--------------------------------------------------------------
void myProject::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void myProject::dragEvent(ofDragInfo dragInfo){ 

}
