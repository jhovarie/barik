#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){
    gui.setup();
    gui.add(intSlider.setup("int slider", 0, 0, 300));
    gui.add(floatSlider.setup("float slider", 33.33, 0.0, 66.66));
    gui.add(toggle.setup("toggle",true));
    gui.add(button.setup("button"));
    
    button.addListener(this, &ofApp::buttonIsClicked);
}

void ofApp::buttonIsClicked() {
    ofLog(OF_LOG_NOTICE,"Button is Clicked");
}

//--------------------------------------------------------------
void ofApp::update(){
 
}

//--------------------------------------------------------------
void ofApp::draw(){

    if(toggle) {
        ofDrawCircle(ofGetWidth()/2, ofGetHeight()/2, intSlider);
        ofDrawRectangle(300, 100, floatSlider, floatSlider);
    }
    
     gui.draw();
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){
    ofLog(OF_LOG_NOTICE, " %d", key);
}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}
