//
//  CircleClass.hpp
//  024ofParameterGuiClass
//
//  Created by Jhovarie on 10/08/2016.
//
//

#ifndef CircleClass_hpp
#define CircleClass_hpp

//#include <stdio.h>
#include "ofMain.h"

class CircleClass {
public:
    void setup();
    void draw();
    
    ofParameterGroup circleParameter;
    ofParameter<int>red;
    ofParameter<int>green;
    ofParameter<int>blue;
    
    ofParameter<int>posX;
    ofParameter<int>posY;
    ofParameter<int>radius;
};

#endif /* CircleClass_hpp */
