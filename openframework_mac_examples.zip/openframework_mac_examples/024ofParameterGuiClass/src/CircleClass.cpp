//
//  CircleClass.cpp
//  024ofParameterGuiClass
//
//  Created by Jhovarie on 10/08/2016.
//
//

#include "CircleClass.hpp"

void CircleClass::setup() {
    circleParameter.setName("circle controls");
    circleParameter.add(red.set("red",255,0,255));
    circleParameter.add(green.set("green",255,0,255));
    circleParameter.add(blue.set("blue",255,0,255));
    circleParameter.add(posX.set("posX",500,0,1000));
    circleParameter.add(posY.set("posY",600,0,800));
    circleParameter.add(radius.set("radius",90,0,1000));
}

void CircleClass::draw() {
    ofSetColor(red, green, blue);
    ofCircle(posX, posY, radius);
}