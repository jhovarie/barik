//
//  SoundClass.cpp
//  017classeswithsound
//
//  Created by Jhovarie on 09/08/2016.
//
//

#include "SoundClass.hpp"

void SoundClass::setup() {
    //drums.load("drum.wav");
    drums.loadSound("drum.wav");
    drums.setVolume(0.3);
    drums.setLoop(true);
}

void SoundClass::keyPressed(int key) {
    switch(key) {
        case ' ':
            drums.play();
            break;
            
        case OF_KEY_LEFT:
            drums.setSpeed(-1.0);
            break;
            
        case OF_KEY_RIGHT:
            drums.setSpeed(1.0);
            break;
            
        case 's':
            drums.stop();
            break;
    }
}