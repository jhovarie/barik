//
//  SoundClass.hpp
//  017classeswithsound
//
//  Created by Jhovarie on 09/08/2016.
//
//

#ifndef SoundClass_hpp
#define SoundClass_hpp

//#include <stdio.h>
#include "ofMain.h"

class SoundClass {
public:
    void setup();
    void keyPressed(int key);
    
    ofSoundPlayer drums;
};

#endif /* SoundClass_hpp */
