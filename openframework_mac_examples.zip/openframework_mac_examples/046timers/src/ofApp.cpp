#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){
    gui.setup();
    gui.add(endTime.set("end Time",1000,0.0,6000));
    
    timerEnd = false;
    startTime = ofGetElapsedTimeMillis();
}

//--------------------------------------------------------------
void ofApp::update(){

}

//--------------------------------------------------------------
void ofApp::draw(){
    gui.draw();
    float barWidth = 600;
    float timer = ofGetElapsedTimeMillis() - startTime;
    if(timer >= endTime){
        timerEnd = true;
    }
    float timerBar = ofMap(timer, 0.0, endTime, 0.0, 1.0, true);
    //ofSetColor(255,255,0);
   // ofDrawRectangle(200, 200, 500, 300);
    ofSetColor(255);
    ofDrawRectangle(ofGetWidth()/2-300, ofGetHeight()/2, barWidth*timerBar, 30);
    //ofRectangle(ofGetWidth()/2-300, ofGetHeight()/2, barWidth*timerBar, 30);
    
    if(timer >= 3000){
        ofSetColor(255,0,0);
        ofCircle(300, 600, 100);
    }
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){
    if(key == ' ') {
        timerEnd = false;
        startTime = ofGetElapsedTimeMillis();
    }
}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}
