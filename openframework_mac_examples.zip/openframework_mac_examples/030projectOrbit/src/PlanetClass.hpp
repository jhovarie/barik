//
//  PlanetClass.hpp
//  030projectOrbit
//
//  Created by Jhovarie on 10/08/2016.
//
//

#ifndef PlanetClass_hpp
#define PlanetClass_hpp

//#include <stdio.h>
#include "ofMain.h"

class PlanetClass {
public:
    void setup();
    void update();
    void draw();
    
    ofParameterGroup planetGroup;
    ofParameter<float>rotateSpeed;
    ofParameter<float>posX;
    ofParameter<float>posY;
    ofParameter<float>radius;
    ofParameter<int>red;
    ofParameter<int>green;
    ofParameter<int>blue;
    
    float rotation = 0.0;
};

#endif /* PlanetClass_hpp */
