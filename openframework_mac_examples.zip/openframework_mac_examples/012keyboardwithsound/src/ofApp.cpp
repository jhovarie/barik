#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){
    synthHit.load("synth.wav");
    synthHit.setLoop(true);
}

//--------------------------------------------------------------
void ofApp::update(){

}

//--------------------------------------------------------------
void ofApp::draw(){
    ofSetColor(200, 0, 0);
    ofDrawBitmapString("Keyboard \n a = start \n o = speed 0.3 \n e = speed -2.0 \n n = speed 1.0 \n u = stop", 50, 50);
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){
    switch(key) {
            case 'a':
            synthHit.play();
            break;
       case 'o':
            synthHit.setSpeed(0.3);
            break;
       case 'e':
            synthHit.setSpeed(-2.0);
            break;
       case 'n':
            synthHit.setSpeed(1.0);
            break;
    }
}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){
    switch(key) {
         case 'u':
            synthHit.stop();
            break;
    }
}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}
